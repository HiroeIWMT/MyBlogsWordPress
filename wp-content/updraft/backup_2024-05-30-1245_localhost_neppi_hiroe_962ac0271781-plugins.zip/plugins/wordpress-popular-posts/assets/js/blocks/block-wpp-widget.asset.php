<?php return array('dependencies' => array(), 'version' => '6f59226254c1dfc89085');
